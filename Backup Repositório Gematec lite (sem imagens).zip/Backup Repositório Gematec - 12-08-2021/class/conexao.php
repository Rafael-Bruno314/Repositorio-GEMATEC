<?php
  $host = "localhost";
  $usuario = "u980373427_AlexandreFerry";
  $senha = "Gematec2006";
  $bd = "u980373427_Gematec";

  $mysqli = new mysqli($host, $usuario, $senha, $bd);
  if($mysqli->connect_errno)
    echo "Falha na conexão: (".$mysqli->connect_errno.") ".$mysqli->connect_error;
?>