<?php
	$banco = "u980373427_Gematec";
	$usuario = "u980373427_AlexandreFerry";
	$senha = "Gematec2006";
	$host = "localhost";

	// Conexão com o banco de dados
	$conn = @mysql_connect($host, $usuario, $senha) or die("Não foi possível a conexão com o Banco");

	// Selecionando banco
	$db = @mysql_select_db($banco, $conn) or die("Não foi possível selecionar o Banco");
?>