# Repositorio GEMATEC
 Um repositório com informações e trabalhos produzidos pelos membros do Grupo de Estudo de Analogias Metáforas e Modelos na Educação Ciência e Tecnologia do CEFET-MG
