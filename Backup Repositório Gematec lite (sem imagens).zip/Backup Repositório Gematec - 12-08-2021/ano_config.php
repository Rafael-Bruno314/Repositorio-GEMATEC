<?php
	header( 'Content-Type: text/html; charset=utf-8' );
  error_reporting(0);
  ini_set(“display_errors”, 0);

  for ($data_ano = date("Y"); $data_ano >= 1980; $data_ano--) {
    $ano_array2[$data_ano] = $data_ano;
  }
?>